# Here are the pages:
[**HOME**](https://tacoscience32.github.io/pages/)  
[**DVD**](https://tacoscience32.github.io/pages/dvd)  
[**BPM** (_bad_)](https://tacoscience32.github.io/pages/bpm-counter)
